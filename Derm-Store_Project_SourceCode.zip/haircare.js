

var data =[
    {
    heart: "♡",
    heart1: "1", 
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12642437-1384891471591053.jpg",
    title: "Christophe Robin Cleansing Purifying Scrub with Sea Salt 75ml ",
    star1: "★★★★★3",    
    star: "3",    
    price: "19.00",
    price1: "$19.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1",
    


    },

   {   heart: "♡",
   heart1: "2",
       img: "https://static.thcdn.com/images/small/webp//productimg/original/12597163-5554871574934407.jpg",
      title: "Olaplex No. 4 Bond Maintenance Shampoo (8.5 fl. oz.)",
      star1: "★★★★★271",
    
    star: "271" ,
      price: "28.00",
      price1: "$28.00",
      btn: "QUICK BUY",
      btn2: "QUICK BUY2"
},

   { 
       heart: "♡",
       heart1: "3",
   img: "https://static.thcdn.com/images/small/webp//productimg/original/11286093-5544866306472227.jpg",
   title: "Alterna CAVIAR Anti-Aging Replenishing Moisture Conditioner (16.5 fl. oz.)",
   star1: "★★★★☆72",    
   star: "72",
      price: "54.00",
      price1: "$54.00",
      btn: "QUICK BUY",
      btn3: "QUICK BUY3"
},
{  
     heart: "♡",
     heart1: "4",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901176-1964866391832598.jpg",
    title: "R+Co DALLAS Biotin Thickening Conditioner (8.5 fl. oz.)",
    star1: "★★★★☆56",    
    star: "56",
    price: "29.00",
    price1: "$29.00",
    btn: "QUICK BUY",
    btn4: "QUICK BUY4"

},
{   heart: "♡",
heart1: "5",
    img: "https://static.thcdn.com/images/small/webp//productimg/1600/1600/12597164-1244777647709491.jpg",
    title: "Olaplex No.5 Bond Maintenance Conditioner 8.5 oz",
    star1: "★★★★★15",    
    star: "15",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn5: "QUICK BUY5"

},
{   heart: "♡",
heart1: "6",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12915558-2034917112938192.jpg",
    title: "Oribe Gold Lust Repair Restore Conditioner (6.8 fl. oz.)",
    star1: "★★★★★123",    
    star: "123",
    price: "52.00",
    price1: "$52.00",
    btn: "QUICK BUY",
    btn6: "QUICK BUY6"

},
{   heart: "♡",
heart1: "6",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12597166-1134871572767741.jpg",
    title: "Olaplex No. 7 Bonding Oil (1 fl. oz.)",
    star1: "★★★★☆153" ,   
    star: "153",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn7: "QUICK BUY7"

},
{   heart: "♡",
heart1: "7",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12597161-1214871574856017.jpg",
    title: "Olaplex No. 3 Hair Perfector (3.3 fl. oz.)",
    star1: "★★★★★346",    
    star: "346",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn8: "QUICK BUY8"

},
{   heart: "♡",
heart1: "8",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13312506-4774896432847542.jpg",
    title: "Olaplex No. 0 Intense Bond Building Hair Treatment (5.2 fl. oz.)",
    star1: "★★★★☆122", 
    star: "122",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn9: "QUICK BUY9"

},
{   heart: "♡",
heart1: "9",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12882753-4324849731787842.jpg",
    title: "Olaplex No 8 Bond Intense Moisture Mask 3.3 fl. oz.",
    star1: "★★★★★47",    
    star: "47",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn10: "QUICK BUY10"

},
{   heart: "♡",
heart1: "10",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12915557-2954917112863726.jpg",
    title: "Oribe Gold Lust Repair Restore Shampoo (8.5 fl. oz.)",
    star1: "★★★★★160",  
    star: "160",
    price: "49.00",
    price1: "$49.00",
    btn: "QUICK BUY",
    btn11: "QUICK BUY11"

},
{   heart: "♡",
heart1: "11",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11286095-7134866306529542.jpg",
    title: "Alterna CAVIAR Anti-Aging Replenishing Moisture Shampoo (16.5 fl. oz.)",
    star1: "★★★★★59",    
    star: "59",
    price: "52.00",
    price1: "$",
    btn: "QUICK BUY",
    btn12: "QUICK BUY12"

},
{   heart: "♡",
heart1: "12",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12596173-9024897198767939.jpg",
    title: "Olaplex Limited Edition Super Size No. 3 Hair Perfector (8.5 fl. oz.)",
    star1: "★★★★★12",    
    star: "12",
    price: "56.00",
    price1: "$56.00",
    btn: "QUICK BUY",
    btn13: "QUICK BUY13"

},
{   heart: "♡",
heart1: "13",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12597165-6984871572661958.jpg",
    title: "Olaplex No. 6 Bond Smoother (3.3 fl. oz.)",
    star1: "★★★★★134" ,   
    star: "134",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn14: "QUICK BUY14"

},
{   heart: "♡",
heart1: "14",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13227262-5924896769540188.jpg",
    title: "Olaplex No. 4-P Blonde Enhancer Toning Shampoo 250ml",
    star1: "★★★★★164" ,   
    star: "164",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn15: "QUICK BUY15"

},
{   heart: "♡",
heart1: "15",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12918894-3264869708983022.jpg",
    title: "Harry Josh Pro Tools Pro Dryer 2000 3 piece",
    star1: "★★★★☆3",    
    star: "3",    
    price: "249.00",
    price1: "$249.00",
    btn16: "QUICK BUY16"

},
{   heart: "♡",
heart1: "16",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902038-8134866432156213.jpg",
    title: "Harry Josh Pro Tools Pro Makeup Wave Setting Clips (6 piece)",
    star1: "★★★★☆101",    
    star: "101",
    price: "18.00",
    price1: "$18.00",
    btn: "QUICK BUY",
    btn17: "QUICK BUY17"

},
{   heart: "♡",
heart1: "17",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12526872-4524872074957712.jpg",
    title: "VIRTUE Healing Oil (1.7 fl. oz.)",
    star1: "★★★★☆342" ,   
    star: "342",
    price: "42.00",
    price1: "$42.00",
    btn: "QUICK BUY",
    btn18: "QUICK BUY18"

},
{   heart: "♡",
heart1: "18",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902631-1774864745852346.jpg",
    title: "Living Proof Restore Instant Protection (5.5 oz.)",
    star1: "★★★★☆7",    
    star: "7",   
     price: "29.00",
    price1: "$29.00",
    btn: "QUICK BUY",
    btn19: "QUICK BUY19"

},
{   heart: "♡",
heart1: "19",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12915670-2114866566888004.jpg",
    title: "Living Proof Restore Instant Protection (5.5 oz.)",
    star1: "★★★★★33",    
    star: "33",
    price: "200.00",
    price1: "$200.00",
    btn: "QUICK BUY",
    btn20: "QUICK BUY20"

},
{   heart: "♡",
heart1: "20",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12903000-1294872045675693.jpg",
    title: "Living Proof Restore Instant Protection (5.5 oz.)",
    star1: "★★★★★11",    
    star: "11",
    price: "12.00",
    price1: "$12.00",
    btn: "QUICK BUY",
    btn21: "QUICK BUY21"

},
{   heart: "♡",
heart1: "21",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12915654-1994869708936438.jpg",
    title: "Harry Josh Pro Tools Ceramic Flat Styling Iron 1.25 Inch (2 piece)",
    star1: "★★★★★97",    
    star: "97",
    price: "30.00",
    price1: "$30.00",
    btn: "QUICK BUY",
    btn22: "QUICK BUY22"

},
{   heart: "♡",
heart1: "22",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901148-1234871548435983.jpg",
    title: "Dermstore Collection Silicone Scalp Massager (1 piece)",
    star1: "★★★★★199",    
    star: "199",
    price: "49.00",
    price1: "$49.00",
    btn: "QUICK BUY",
    btn23: "QUICK BUY23"

},
{   heart: "♡",
heart1: "23",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11310921-1004895711663196.jpg",
    title: "Harry Josh Pro Tools Pro Dryer 2000 Diffuser (1 piece)",
    star1: "★★★★★98",    
    star: "98",
    price: "48.00",
    price1: "$48.00",
    btn: "QUICK BUY",
    btn24: "QUICK BUY24"

},
{   heart: "♡",
heart1: "24",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902240-2654866434013054.jpg",
    title: "Oribe Silverati Shampoo (8.5 oz.)",
    star1: "★★★★☆35",    
    star: "35",
    price: "46.00",
    price1: "$46.00",
    btn: "QUICK BUY",
    btn: "QUICK BUY1"

},
{   heart: "♡",
heart1: "25",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902460-2004866427553508.jpg",
    title: "Oribe Dry Texturizing Spray (8.5 oz.)",
    star1: "★★★★★18",    
    star: "18",
    price: "90.00",
    price1: "$90.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "26",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902037-4044866432108096.jpg",
    title: "Living Proof Perfect hair Day Dry Shampoo (7.3 oz.)",
    star1: "★★★★★45",    
    star: "45",
    price: "32.00",
    price1: "$32.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "27",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901140-9424904191542093.jpg",
    title: "Harry Josh Pro Tools Travel Curling Iron 1.25 Inch (1 piece)",
    star1: "★★★★☆83",    
    star: "83",
    price: "45.00",
    price1: "$45.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "28",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12918920-2054866556682202.jpg",
    title: "R+Co TELEVISION Perfect Hair Shampoo (8 fl. oz.)",
    star1: "★★★★★70",    
    star: "70",
    price: "349.00",
    price1: "$349.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "29",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11310915-1314917112694313.jpg",
    title: "Miriam quevedo Black Baccara with Fresh Rose Stem Cells Hair Multiplying Shampoo (8.5 fl. oz.)",
    star1: "★★★★★45",    
    star: "45",
    price: "56.00",
    price1: "$56.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "30",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901616-1094866428211318.jpg",
    title: "Oribe Gold Lust Nourishing Hair Oil (3.4 fl. oz.)",
    star1: "★★★★★112",    
    star: "122",
    price: "15.00",
    price1: "$15.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "31",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11128858-1114866125771796.jpg",
    title: "Harry Josh Pro Tools Ultra Light Pro Dryer 3 piece",
    star1: "★★★★★15",    
    star: "15",
    price: "38.00",
    price1: "$38.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "2",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902457-7804866427412838.jpg",
    title: "Harry Josh Pro Tools Pro Styling Clips (3 count)",
    star1: "★★★★★85",    
    star: "85",
    price: "46.00",
    price1: "$46.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "32",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901969-1034866428116257.jpg",
    title: "Oribe Styling Butter Curl Enhancing Creme (6.7 fl. oz.)",
    star1: "★★★★☆354",    
    star: "354",
    price: "29.00",
    price1: "$29.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "33",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13205278-1974885475502363.jpg",
    title: "Briogeo Don't Despair Repair Deep Conditioning Mask (8 oz.)",
    star1: "★★★★★51",    
    star: "51",
    price: "60.00",
    price1: "$60.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "2",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902241-1824866434051820.jpg",
    title: "Olaplex Healthy Hair Essentials Kit (Worth 28.0084.00)",
    star1: "★★★★★10",    
    star: "10",
    price: "48.00",
    price1: "$48.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "34",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901087-1364866390003951.jpg",
    title: "Oribe Silverati Conditioner (6.8 fl. oz.)",
    star1: "★★★★☆10",    
    star: "10",
    price: "37.00",
    price1: "$37.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "35",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901071-4774900275484872.jpg",
    title: "R+Co FOIL Frizz Static Control Spray (5 oz.)",
    star1: "★★★★★34",    
    star: "34",
    price: "36.00",
    price1: "$36.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "36",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12902036-1674866432051675.jpg",
    title: "Oribe Run-Through Detangling Primer (5.9 fl. oz.)",
    star1: "★★★★★30",    
    star: "30",
    price: "32.00",
    price1: "$32.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "37",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901086-1784871819005896.jpg",
    title: "Rahua Hydration Shampoo (9.3 fl. oz.)",
    star1: "★★★★★25",    
    star: "25",
    price: "48.00",
    price1: "$48.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "38",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901318-2104872070200669.jpg",
    title: "R+Co TELEVISION Perfect Hair Conditioner (8 fl. oz.)",
    star1: "★★★★58",    
    star: "58",   
    price: "20.00",
    price1: "$20.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "39",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13321541-2024896637232238.jpg",
    title: "Oribe Gold Lust Dry Shampoo (6 oz.)",
    star1: "★★★★☆13",    
    star: "13",
    price: "18.00",
    price1: "$18.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "40",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11310890-8734897199193951.jpg",
    title: "Regenepure NT Nourishing Treatment (8 fl. oz.)",
    star1: "★★★★★67",    
    star: "67", 
    price: "52.00",
    price1: "$52.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "41",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11310876-1654895711338701.jpg",
    title: "Oribe Gold Lust Repair Restore Conditioner- Travel (1.7 fl. oz.)",
    star1: "★★★★★118",    
    star: "118",
    price: "46.00",
    price1: "$46.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "42",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/11310875-1284895711320479.jpg",
    title: "Oribe Gold Lust Repair Restore Conditioner- Travel (1.7 fl. oz.)",
    star1: "★★★★★10",    
    star: "10",
    price: "28.00",
    price1: "$28.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "43",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/12901088-1684876994436489.jpg",
    title: "Oribe Shampoo for Magnificent Volume (8.5 fl. oz.)",
    star1: "★★★★★1",    
    star: "1",   
    price: "19.00",
    price1: "$19.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "44",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13175693-1054889419083984.jpg",
    title: "Living Proof Perfect hair Day (PhD) Advanced Clean Dry Shampoo 2.4 oz.",
    star1: "★★★★★22",    
    star: "22",
    price: "16.00",
    price1: "$16.00",
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

},
{   heart: "♡",
heart1: "45",
    img: "https://static.thcdn.com/images/small/webp//productimg/original/13227149-1424904230440945.jpg",
    title: "UNITE Pure Hydration Prep Set (Worth $28.0090.00)",
    star1: "★★★★★33",    
    star: "33",
    price: "51.00",
     price1: "$51.00", 
    btn: "QUICK BUY",
    btn1: "QUICK BUY1"

}



];
 
  var nextpagearr = JSON.parse(localStorage.getItem("details")) || [];
 displaytem(data);

function sortarr () {
    var selected = document.querySelector("#sortby").value;
    console.log(selected);
    if(selected == "High"){
        data.sort(function (a,b){
            return Number(b.price) - Number(a.price);
        });
        
    }
    else if(selected == "Low"){
        data.sort(function (a,b){
            return Number(a.price) - Number(b.price);
        });
        
    }
    else if(selected == "A - Z"){
        data.sort(function (a,b){
            if (a.title > b.title)
            return 1;
            if (a.title < b.title)
            return -1;
        });
        
        
    }
    else if(selected == "Default" || selected == "Newest Arrivals" || selected == "Percentage Discount"){
        
        
         data.sort(function (a,b){
             return a.heart1 - b.heart1;
         });
        
    }
    else if(selected == "Bestsellers"){
        data.sort(function (a,b){
            return Number(b.star) - Number(a.star);
        });
        
    }

    displaytem(data);
    console.log(data); 
    localStorage.setItem("mydata" , JSON.stringify(data));
}


function displaytem(data){
    document.querySelector(".hairproducts1").textContent = "";
data.map(function(elem, index){
    var div1 = document.createElement("div");
    div1.setAttribute("id" , "div1")

   var div2 = document.createElement("div");
   div2.setAttribute("id" , "div2");

   var h2 = document.createElement("h2");
   h2.textContent = elem.heart;

   var div3 =  document.createElement("div");
   div3.setAttribute("id" , "div3");
   div2.addEventListener("click" , function(){
            nextpage(elem,index);
        });
        div3.addEventListener("click" , function(){
            nextpage(elem,index);
        });
   var div4 = document.createElement("div");
   div4.setAttribute("id" , "div4");
   var ptitle = document.createElement("p");
    ptitle.textContent = elem.title;
   div4.append(ptitle);
    
   var image = document.createElement("img");
   image.setAttribute("src" , elem.img);
   image.setAttribute('id', 'image')

   var div7 = document.createElement("div");
   div7.setAttribute("id" , "div7");

   var star1 = document.createElement("h3");
   star1.textContent = elem.star1; 


var div5 = document.createElement("div");
div5.setAttribute("id" , "div5"); 

var price1 = document.createElement("h4");
price1.setAttribute("id" , "price1"); 
price1.textContent = elem.price1;

var div6 = document.createElement("div");
div6.setAttribute("id" , "div6"); 

   var btn = document.createElement("button");
   btn.textContent = elem.btn;
   btn.setAttribute('id', 'addtocartbut')
     
   btn.addEventListener("click" , function(){
      buynow(elem,index);
      
   });

  
   


    div6.append(btn);
    div5.append(price1);
    div7.append(star1)
   div3.append(image);
   div2.append(h2);
    div1.append(div2,div3,div4,div7,div5,div6)
   document.querySelector(".hairproducts1").append(div1);
   


});

function nextpage(elem , index){
    nextpagearr.splice(0,index);
     nextpagearr.push(elem);
     localStorage.setItem("details" , JSON.stringify(nextpagearr));
 
     console.log(elem);
    
    //  window.location.href = "haircareProd.html";


    }

document.querySelector('#image').addEventListener('click', function(){
    window.location.href = 'haircareProd.html'
})

    function 
      buynow(index){
      window.location.href = "dem4.html";
   }
}














var exp = false;
    function showcheck (){
        var checkbox = document.getElementById("checkbox");
        if (!exp){
            checkbox.style.display = "block";
        }  
        else{
            checkbox.style.display = "none";
            exp = false;
        }
    }

    var exp1 = false;
    function showcheck1 (){
        var checkbox = document.getElementById("checkbox1");
        if (!exp1){
            checkbox1.style.display = "block";
        }  
        else{
            checkbox1.style.display = "none";
            exp1 = false;
        }
    }

    var exp2 = false;
    function showcheck2 (){
        var checkbox = document.getElementById("checkbox2");
        if (!exp2){
            checkbox2.style.display = "block";
        }  
        else{
            checkbox2.style.display = "none";
            exp2 = false;
        }
    }

    var exp3 = false;
    function showcheck3 (){
        var checkbox3 = document.getElementById("checkbox3");
        if (!exp3){
            checkbox3.style.display = "block";
        }  
        else{
            checkbox3.style.display = "none";
            exp3 = false;
        }
    }

    var exp4 = false;
    function showcheck4 (){
        var checkbox = document.getElementById("checkbox4");
        if (!exp4){
            checkbox4.style.display = "block";
        }  
        else{
            checkbox4.style.display = "none";
            exp4 = false;
        }
    }

    var exp5 = false;
    function showcheck5 (){
        var checkbox5 = document.getElementById("checkbox5");
        if (!exp5){
            checkbox5.style.display = "block";
        }  
        else{
            checkbox5.style.display = "none";
            exp5 = false;
        }
    }

    var exp6 = false;
    function showcheck6 (){
        var checkbox6 = document.getElementById("checkbox6");
        if (!exp6){
            checkbox6.style.display = "block";
        }  
        else{
            checkbox6.style.display = "none";
            exp6 = false;
        }
    }


    var exp7 = false;
    function showcheck7 (){
        var checkbox7 = document.getElementById("checkbox7");
        if (!exp7){
            checkbox7.style.display = "block";
        }  
        else{
            checkbox7.style.display = "none";
            exp7 = false;
        }
    }

    var exp8 = false;
    function showcheck8 (){
        var checkbox8 = document.getElementById("checkbox8");
        if (!exp8){
            checkbox8.style.display = "block";
        }  
        else{
            checkbox8.style.display = "none";
            exp8 = false;
        }
    }

    var exp9 = false;
    function showcheck9 (){
        var checkbox9 = document.getElementById("checkbox9");
        if (!exp9){
            checkbox9.style.display = "block";
        }  
        else{
            checkbox9.style.display = "none";
            exp9 = false;
        }
    }

    var exp10 = false;
    function showcheck10 (){
        var checkbox10 = document.getElementById("checkbox10");
        if (!exp10){
            checkbox10.style.display = "block";
        }  
        else{
            checkbox10.style.display = "none";
            exp10 = false;
        }
    }

    var exp11 = false;
    function showcheck11 (){
        var checkbox11 = document.getElementById("checkbox11");
        if (!exp11){
            checkbox11.style.display = "block";
        }  
        else{
            checkbox11.style.display = "none";
            exp11 = false;
        }
    }


   document.querySelector('#logoutbut').addEventListener('click', function(){
       window.location.href = 'login.html';
   })

   document.querySelector('.signmeupbutton').addEventListener('click', function(){
       window.location.href = 'register.html';
   })