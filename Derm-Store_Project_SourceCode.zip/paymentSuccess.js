
document.querySelector('#button').addEventListener('click', function(){
    window.location.href = 'index.html';
})

document.querySelector('.img').addEventListener('click', function(){
    window.location.href = 'index.html';
})